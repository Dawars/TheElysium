Sn0wZ0ne 1.0
Sn0wSong 1.45

For all versions of Minecraft.
OP/Text/Readme for all versions and variations of Sn0wZ0ne, Sn0wSong and the Sn0w Shepherd Total Conversion of Minecraft recombination of the two into one glorious Resource Pack.

The Total Conversion Resource Pack for Minecraft!

SnowSong 1.45 - Better Sound for Minecraft...MUCH better!
Sn0wZ0ne 1.0 - Transforming Minecraft Into a Dark Visionary's Manic Mosaic of Paintings for Fun!

Sn0wSong

This is 100% original Sound FX and Music with engineering, composition, performance and misteressing entirely designed and completed by The Sn0w Shepherd, aka Mama Sn0w, renowned artist, singer, songwriter, poet, author of college texts in Sociological Studies and global speaker on the subject of Gender Sex and Sexuality, and on Encouraging the End of Male Violence Against Females.

Sn0wZ0ne

You tried every texture pack in the known Multiverse, and never found any ONE that had perfect continuity in which every texture was seamlessly a part of a single vision good enough to keep your attention from dirt blocks to Beacon GUI. Discouraged, you assembled your own multi-resource Resource Pack of sorts the way Dr. Frankenstein assembled his notoriously misunderstood replicant.  But then you heard a dragonfly fresh from the swamps of the Shivering Isles speak cautiously of a lunatic at the edge of sanity, a female of talent and power to be both feared and giggled at, who was to not be less than regularly dwelling in her own headspace somewhere near the untied state of Confusion in Minnesota.  Then you found out that she had painted a really HUGE mosaic of tiny water color paintings that all fit together perfectly into this neat 3D realm called Sn0wZ0ne.  The only way to visualize her madness you then learned was to load all of the tiny tiles into the only video game engine capable of arranging them according to her bizarre obsession:  Mojang's "Minecraft".

The Dragonfly's Legend holds that Sn0w was once the greatest Minecraft player of all time, and had been one of the greatest Guitar Heroes and XBOX gamers and Twitch.tv Streamers ever...at least...before the accident that left her completely MAD.  No one is quite certain WHY or HOW the "accident" had managed to drive her completely mad, but those who knew her from before the "accident" said that the drive was short, the gasoline only a few drops burnt and the trip just around the corner from where she spent most of her time anyway.  The accident, well, let's just say bubble gum, rubber bands and tin foil do not always mix.

Triggering all of these events and most of these peculiar statements about Sn0w's mental instability, someone in her Twitch.tv channel's chat room planted an idea deep within her tiny little brain; which really is an oxymoron if you bother to think about it; you know, like, how could depth of greatness be found within such a tiny zombie snack as Sn0w's gray matter?  Regardless...and this happened at night, mind you, while she was killing yet another Wither while whistling the theme song to the original 1970s version of Doctor Who.  A seemingly harmless line of text mentioned to her, "The rain sound is too loud!" Although Sn0w was at Y-10 with this particular Wither, beneath a desert village, and it being still a Tuesday, she screamed, "You're right! It IS too loud!  And worse yet, it doesn't even SOUND like a decent rain!"

This was the impetus that launched her forth.  No one recalls the net-handle of the one who made first inception of this idea, but the rain sound was indeed far too loud and needed to be made less loud somehow.  Works of 1000s of hours later, Sn0wSong 1.45 was released, replacing EVERY sound and EVERY song in the entire game of Minecraft...not just the originally annoying sounds of Zombie Door Smashers and "Bad Rain!" Many times Sn0w postulated, "Why did Mojang pay so much for such garbage sounds?!  And what was the name of that so-called pro team of sound engineers that got said pay?  And what degree of pay for said engineers was wasted by them on said garbage sound development and/or said postulations about coconut hybridizations for the purpose of equine effect emulation in midevial settings?!"  MANY times, she postulated this, and hence, she lost many, MANY viewers and followers.  Digressing, a second inception was attempted once the Sn0wSong was finsihed.

"You should make a texture pack to go along with the sounds!" posted a viewer who's name is withheld from here in order to try to protect their bloods.

It was months after this was said that it actually sank in through the immeasurable number of super-dense layers of skull wrapped around Sn0w's miniscule zombie tooth cavity-filler of a neural mass... months that were subsequently saturated heavily with hundreds of identical requests from other viewers and sources both real and supposedly imaginary.  She shouted, ultimately, after falling into a river at the bottom of a ravine that was filled with suspiciously-gathered sheep near a small village during a Magic Farm 2 MOD Pack session, "Oh my LORD!  Look at the sheep!  How did you sheepies get down here?!  Silly sheepies!"

A few months later, she just started painting textures for no apparent reason.

Now, the mosaic is complete, and the textures we have finally wrenched from the retched wench's wrung wrists with willful and wistful wowies to boot...oh...and a boot to her head to loosen her grip on them and tighten her grip on the reality of pain.  Here it is!  Sn0wZ0ne!  The product of when Sn0w zoned out for SIX months, all by herself, with digital brush and tablet in hand and lap and made this really neat crayon drawing of a bloody painting of her inner darkness which itself had been ever previously present while she had been living Minecraft cutely.

Sn0wZ0ne is, fortunately for all of us, entirely an original work of Sn0w's mind, art and shakey hands.  No other entities have been named as co-conspirators of its creation save one...one known only as H�nir the Silent.  The tribal butterfly that adorns every chest/treasure box belongs to the namesake of the great Norse God of Arboris Motus Animatum...friend of Sn0w and her dubious lineage in L��urr.

INSTALL

Should you dare install this thing, it is actually surprisingly easy to do so!

Place the zip file containing this file and all the others into your resourcepacks folder and start the Minecraft from your choice of launcher.  When the game has finished loading, click the Options button and then click Resource Packs.  Continue clicking little arrows and sliders and such until you find this file's Zip-Skin file and click its pretty little icon with the neat white Snow Leopard outline to it (Sn0w fancies herself to actually BE a Snow Leopard Anthro Khajiit Dragonborn Mistress of the Red Hand from Tamriel...yeah....told ya....CRAY-ZEE!!!)!!!

Anyway, that's it.  It will take a while for this large file to parse into the Minecraft cache for repainting your Minecraft worlds in madness and unadulterated silly.  Done, done and done!  Oh, and click DONE when it's done, too.

Now, play and enjoy a brand new game experience from within the Minecraft engine!

This OP and text brought to you by:

Overly-Wordy OPs and Textseses of Formerly-Free America

LINKS!

Yes, we have some left over from where we had to chain Mama Sn0w (the dark lady of BLOOD decended from or actually Elsz�bet Bathory herself somehow, princess of shadow, princess of darkness, the crazy cat lady with no cats) down...but now the links look more like data for a Universal Resource Locator of some sort than bits of titanium chain for some unknown reason.

Good luck with these!

Sn0w's Creatives Page:

http://www.aleciashepherd.com/

Sn0w's Deviant Art Page:

http://aleciashepherd.deviantart.com/gallery/

Sn0w's TWITCH Page:

http://www.twitch.tv/sn0wshepherd

Sn0wSong Download Location:

http://www.aleciashepherd.com/SnowSong/Sn0wSong1.45_MC17x.zip

...or, download the Child-Safe No-Hurt version From:

http://www.aleciashepherd.com/SnowSong/Sn0wSong1.45_MC17xNH.zip

Sn0wZ0ne Download Location:

http://www.aleciashepherd.com/SnowSong/Sn0wZ0ne-512X_MC17x.zip

Sn0wZone + Sn0wSong Total Conversion Download Location:

http://www.aleciashepherd.com/SnowSong/Sn0wZ0ne-TC_MC17x-512X.zip

Sn0wZone + Sn0wSong Total Conversion Download Location - No Hurt Version:

http://www.aleciashepherd.com/SnowSong/Sn0wZ0ne-TC_MC17xNH-512X.zip

Sn0w's Chapbook of Poetry:

http://www.aleciashepherd.com/HOTGM_Alecia_Shepherd_Chapbook.pdf

God bless you, and I hope you enjoy this exceptional endeavor to properly, professionally engineer total immersion into your worlds of Minecraft.  Thank you, Notch.

NOTE:

Sn0wSong version 1.45 fixes certain volume issues with Mojang's tampering with default settings
and such.  It also replaces a few sound effects (three actually) that were considered "lower in
quality" than all the other effects.  Also, two songs assigned to the 1.7x MENU selection of music
have been remastered to remove errant gain distortion.

::HUGS from Mama Sn0w::