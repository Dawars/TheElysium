package me.dawars.CraftingPillars;

public class BlockIds
{

	//Settings
	public static int sentryCooldown = 20;
	public static float sentryRange = 16*16;

}